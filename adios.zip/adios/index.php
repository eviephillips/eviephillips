<?php
/**
 * Index Page
 *
 * @package adios
 * @since 1.0
 */
get_template_part('page-templates/blog-list');

