<?php
/**
 * Footer file
 *
 * @package adios
 * @since 1.0
 */
?>

<?php adios_footer_template(); ?>
<?php wp_footer(); ?>
</body>
</html>
