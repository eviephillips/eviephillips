<?php
/**
 * Loop
 *
 * @package adios
 * @since 1.0
 */
?>
<div class="col-md-12">
  <h4><?php echo esc_html__('Sorry No Post Found !', 'adios'); ?></h4>
</div>
