<?php

  require_once( get_template_directory().'/framework/admin/redux-extensions/extensions-init.php' );
  require_once( get_template_directory() . '/framework/admin/metaboxes-init.php' );
  require_once( get_template_directory().'/framework/admin/options-init.php' );
