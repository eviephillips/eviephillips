<?php
/*
 * Post
*/
$sections[] = array(
  'icon' => 'el-icon-screen',
  'fields' => array(
    array(
      'id'        => 'post-audio-id',
      'type'      => 'text',
      'title'     => esc_html__('Sound Cloud ID', 'adios'),
      'default'   => '',
    ),
  )
);
