<?php
/*
 * Portfolio genearal
*/
$sections[] = array(
  'icon'   => 'el-icon-adjust-alt',
  'title'  => esc_html__('General settings', 'adios'),
  'fields' => array(
    array(
      'id'        => 'portfolio-gallery',
      'type'      => 'slides',
      'title'     => esc_html__('Gallery', 'adios'),
      'subtitle'  => esc_html__('Upload images or add from media library.', 'adios'),
      'placeholder'   => array(
        'title' => esc_html__('Title', 'adios'),
      ),
      'show' => array(
        'title' => true,
        'description' => false,
        'url' => false,
      ),
    ),
  ), // #fields
);
